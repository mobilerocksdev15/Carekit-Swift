//
//  CareKitActivity.swift
//  BodyMeasurements
//
//  Created by Ritesh  on 05/07/17.
//  Copyright © 2017 Ritesh. All rights reserved.
//

import Foundation
import CareKit

class CareKitActivity: NSObject {
    static let groupId = "GroupID"
    
    //MARK: - Create Schedule 
    static private func getSchedule() -> OCKCareSchedule! {
        let startDateComponents = DateComponents.init(year: 1, month: 1, day: 1)
        let schedule = OCKCareSchedule.weeklySchedule(withStartDate: startDateComponents, occurrencesOnEachDay: [1, 1, 1, 1, 1, 1, 1])
        return schedule
    }
    
    //MARK: - Activity Creation
    static func createBodyMassActivity() -> OCKCarePlanActivity! {
        let bodyMassActivity = OCKCarePlanActivity.assessment(withIdentifier: ConstantBodyMassActivity.id, groupIdentifier: groupId, title: ConstantBodyMassActivity.title, text: ConstantBodyMassActivity.text, tintColor: ConstantBodyMassActivity.color, resultResettable: true, schedule: self.getSchedule()!, userInfo:  ["Type":ConstantBodyMassActivity.type], thresholds:nil, optional:false)
        return bodyMassActivity
    }
    
    static func createHeightActivity() -> OCKCarePlanActivity! {
        let heightActivity = OCKCarePlanActivity.assessment(withIdentifier: ConstantHeightActivity.id, groupIdentifier: groupId, title: ConstantHeightActivity.title, text: ConstantHeightActivity.text, tintColor: ConstantHeightActivity.color, resultResettable: true, schedule: self.getSchedule()!, userInfo:  ["Type":ConstantHeightActivity.type], thresholds:nil, optional:false)
        return heightActivity
    }
    
    static func createBodyFatActivity() -> OCKCarePlanActivity! {
        let bodyFatActivity = OCKCarePlanActivity.assessment(withIdentifier: ConstantBodyFatActivity.id, groupIdentifier: groupId, title: ConstantBodyFatActivity.title, text: ConstantBodyFatActivity.text, tintColor: ConstantBodyFatActivity.color, resultResettable: true, schedule: self.getSchedule()!, userInfo:  ["Type":ConstantBodyFatActivity.type], thresholds:nil, optional:false)
        return bodyFatActivity
    }
    
    static func createLeanBodyMassActivity() -> OCKCarePlanActivity! {
        let leanBodyMassActivity = OCKCarePlanActivity.assessment(withIdentifier: ConstantLeanBodyMassActivity.id, groupIdentifier: groupId, title: ConstantLeanBodyMassActivity.title, text: ConstantLeanBodyMassActivity.text, tintColor: ConstantLeanBodyMassActivity.color, resultResettable: true, schedule: self.getSchedule()!, userInfo:  ["Type":ConstantLeanBodyMassActivity.type], thresholds:nil, optional:false)
        return leanBodyMassActivity
    }
    
    static func createBodyMassIndexActivity() -> OCKCarePlanActivity! {
        let bodyMassIndex = OCKCarePlanActivity.assessment(withIdentifier: ConstantBodyMassIndexActivity.id, groupIdentifier: groupId, title: ConstantBodyMassIndexActivity.title, text: ConstantBodyMassIndexActivity.text, tintColor: ConstantBodyMassIndexActivity.color, resultResettable: true, schedule: self.getSchedule()!, userInfo:  ["Type":ConstantBodyMassIndexActivity.type], thresholds:nil, optional:false)
        return bodyMassIndex
    }
    
}
