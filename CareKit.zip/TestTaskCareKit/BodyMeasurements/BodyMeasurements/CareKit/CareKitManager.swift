//
//  CareKitManager.swift
//  BodyMeasurements
//
//  Created by Ritesh  on 05/07/17.
//  Copyright © 2017 Ritesh. All rights reserved.
//

import UIKit
import CareKit

class CareKitManager: NSObject {
    
    static private var carePlanStore:OCKCarePlanStore?
    
    //MARK: - CarePlanStore initialization
    static func createCarePlanStore() {
        let documentsDirectory = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true)
        let dataPath = documentsDirectory[0] + "/CarePlanHealth"
        if !FileManager.default.fileExists(atPath: dataPath) {
            do {
                try FileManager.default.createDirectory(atPath: dataPath, withIntermediateDirectories: false, attributes: nil)
            } catch(_) {
                assertionFailure("Unable to Create Directory for CarePlanHealth")
            }
        }
        carePlanStore = OCKCarePlanStore.init(persistenceDirectoryURL: URL.init(string: dataPath)!)
        carePlanStore?.activities(completion: { (isActive, activities, error) in
            if activities.isEmpty {
                self.setActivityForHealthData()
            } else {
                return
            }
        })
    }
    
    //MARK: - Health Activity
    static private func setActivityForHealthData() {
        let bodyMassActivity = CareKitActivity.createBodyMassActivity()!
        carePlanStore?.add(bodyMassActivity, completion: { (boolVal, error) in
            assert(boolVal, (error?.localizedDescription)!)
        })
        let heightActivity = CareKitActivity.createHeightActivity()!
        carePlanStore?.add(heightActivity, completion: { (boolVal, error) in
            assert(boolVal, (error?.localizedDescription)!)
        })
        let bodyFatActivity = CareKitActivity.createBodyFatActivity()!
        carePlanStore?.add(bodyFatActivity, completion: { (boolVal, error) in
            assert(boolVal, (error?.localizedDescription)!)
        })
        let leanBodyMassActivity = CareKitActivity.createLeanBodyMassActivity()!
        carePlanStore?.add(leanBodyMassActivity, completion: { (boolVal, error) in
            assert(boolVal, (error?.localizedDescription)!)
        })
        let bodyMassIndex = CareKitActivity.createBodyMassIndexActivity()!
        carePlanStore?.add(bodyMassIndex, completion: { (boolVal, error) in
            assert(boolVal, (error?.localizedDescription)!)
        })
    }
    
    //MARK: - Controller
    static func getSymptomTrackerController() -> OCKSymptomTrackerViewController{
        return OCKSymptomTrackerViewController.init(carePlanStore: carePlanStore!)
    }
    
}
