//
//  HealthKitDataProvider.swift
//  BodyMeasurements
//
//  Created by Ritesh  on 05/07/17.
//  Copyright © 2017 Ritesh. All rights reserved.
//

import UIKit
import HealthKit
import CareKit

class HealthKitDataProvider: NSObject {
    
    //MARK: - Update CarePlanStore
    static func updateStore(_ viewController: OCKSymptomTrackerViewController, assessmentEvent: OCKCarePlanEvent, result: OCKCarePlanEventResult) {
        viewController.store.update(assessmentEvent, with: result, state: OCKCarePlanEventState.completed, completion: { (boolVal, event, error) in
            assert(boolVal, (error?.localizedDescription)!)
        })
    }
    
    //MARK: - Set HealthKit data on CareKit UI
    static func setBodyMass(_ viewController: OCKSymptomTrackerViewController, assessmentEvent: OCKCarePlanEvent) {
        if (HealthKitManager.getHealthKitStore()?.authorizationStatus(for: HKQuantityType.quantityType(forIdentifier: HKQuantityTypeIdentifier.bodyMass)!)) == HKAuthorizationStatus.sharingAuthorized {
            self.readHKSample(HKQuantityType.quantityType(
                forIdentifier: HKQuantityTypeIdentifier.bodyMass)!, completion: { (sample, error) in
                    guard let samepleQuery = sample else {
                        MessageAlert.displayAlert(alertTitle: "Alert!", alertMessage: ConstantAlert.healthSettingMessage)
                        return
                    }
                    let querryResult = OCKCarePlanEventResult.init(quantitySample: samepleQuery as! HKQuantitySample, quantityStringFormatter: nil, display: HKUnit.pound(), displayUnitStringKey: "lbs", userInfo: nil)
                    self.updateStore(viewController, assessmentEvent: assessmentEvent, result: querryResult)
            })
        } else {
            MessageAlert.displayAlert(alertTitle: "Alert!", alertMessage: ConstantAlert.healthSettingMessage)
        }
    }
    
    static func setHeight(_ viewController: OCKSymptomTrackerViewController, assessmentEvent: OCKCarePlanEvent) {
        if (HealthKitManager.getHealthKitStore()?.authorizationStatus(for: HKQuantityType.quantityType(forIdentifier: HKQuantityTypeIdentifier.height)!)) == HKAuthorizationStatus.sharingAuthorized {
            self.readHKSample(HKQuantityType.quantityType(
                forIdentifier: HKQuantityTypeIdentifier.height)!, completion: { (sample, error) in
                    guard let samepleQuery = sample else {
                        MessageAlert.displayAlert(alertTitle: "Alert!", alertMessage: ConstantAlert.healthSettingMessage)
                        return
                    }
                    let querryResult = OCKCarePlanEventResult.init(quantitySample: samepleQuery as! HKQuantitySample, quantityStringFormatter: nil, display: HKUnit.foot(), displayUnitStringKey: "ft", userInfo: nil)
                    self.updateStore(viewController, assessmentEvent: assessmentEvent, result: querryResult)
            })
        } else {
            MessageAlert.displayAlert(alertTitle: "Alert!", alertMessage: ConstantAlert.healthSettingMessage)
        }
    }
    
    static func setLeanBodyMass(_ viewController: OCKSymptomTrackerViewController, assessmentEvent: OCKCarePlanEvent) {
        if (HealthKitManager.getHealthKitStore()?.authorizationStatus(for: HKQuantityType.quantityType(forIdentifier: HKQuantityTypeIdentifier.leanBodyMass)!)) == HKAuthorizationStatus.sharingAuthorized {
            self.readHKSample(HKQuantityType.quantityType(
                forIdentifier: HKQuantityTypeIdentifier.leanBodyMass)!, completion: { (sample, error) in
                    guard let samepleQuery = sample else {
                        MessageAlert.displayAlert(alertTitle: "Alert!", alertMessage: ConstantAlert.healthSettingMessage)
                        return
                    }
                    let querryResult = OCKCarePlanEventResult.init(quantitySample: samepleQuery as! HKQuantitySample, quantityStringFormatter: nil, display: HKUnit.pound(), displayUnitStringKey: "lbs", userInfo: nil)
                    self.updateStore(viewController, assessmentEvent: assessmentEvent, result: querryResult)
            })
        } else {
            MessageAlert.displayAlert(alertTitle: "Alert!", alertMessage: ConstantAlert.healthSettingMessage)
        }
    }
    
    static func setBodyFat(_ viewController: OCKSymptomTrackerViewController, assessmentEvent: OCKCarePlanEvent) {
        if (HealthKitManager.getHealthKitStore()?.authorizationStatus(for: HKQuantityType.quantityType(forIdentifier: HKQuantityTypeIdentifier.bodyFatPercentage)!)) == HKAuthorizationStatus.sharingAuthorized {
            self.readHKSample(HKQuantityType.quantityType(
                forIdentifier: HKQuantityTypeIdentifier.bodyFatPercentage)!, completion: { (sample, error) in
                    guard let samepleQuery = sample else {
                        MessageAlert.displayAlert(alertTitle: "Alert!", alertMessage: ConstantAlert.healthSettingMessage)
                        return
                    }
                    let querryResult = OCKCarePlanEventResult.init(quantitySample: samepleQuery as! HKQuantitySample, quantityStringFormatter: nil, display: HKUnit.percent(), displayUnitStringKey: "X100 %", userInfo: nil)
                    self.updateStore(viewController, assessmentEvent: assessmentEvent, result: querryResult)
            })
        } else {
            MessageAlert.displayAlert(alertTitle: "Alert!", alertMessage: ConstantAlert.healthSettingMessage)
        }
    }
    
    static func setBodyMassIndex(_ viewController: OCKSymptomTrackerViewController, assessmentEvent: OCKCarePlanEvent) {
        if (HealthKitManager.getHealthKitStore()?.authorizationStatus(for: HKQuantityType.quantityType(forIdentifier: HKQuantityTypeIdentifier.bodyMassIndex)!)) == HKAuthorizationStatus.sharingAuthorized {
            self.readHKSample(HKQuantityType.quantityType(
                forIdentifier: HKQuantityTypeIdentifier.bodyMassIndex)!, completion: { (sample, error) in
                    guard let samepleQuery = sample else {
                        MessageAlert.displayAlert(alertTitle: "Alert!", alertMessage: ConstantAlert.healthSettingMessage)
                        return
                    }
                    let querryResult = OCKCarePlanEventResult.init(quantitySample: samepleQuery as! HKQuantitySample, quantityStringFormatter: nil, display: HKUnit.count(), displayUnitStringKey: "BMI", userInfo: nil)
                    self.updateStore(viewController, assessmentEvent: assessmentEvent, result: querryResult)
            })
        } else {
            MessageAlert.displayAlert(alertTitle: "Alert!", alertMessage: ConstantAlert.healthSettingMessage)
        }
    }
    
    //MARK: - Read HealthKit data
    static func readHealthKitData(type: String!, _ viewController: OCKSymptomTrackerViewController, assessmentEvent: OCKCarePlanEvent) {
        switch type {
        case ConstantBodyMassActivity.type:
            self.setBodyMass(viewController, assessmentEvent: assessmentEvent)
            break
            
        case ConstantHeightActivity.type:
            self.setHeight(viewController, assessmentEvent: assessmentEvent)
            break
            
        case ConstantBodyFatActivity.type:
            self.setBodyFat(viewController, assessmentEvent: assessmentEvent)
            break
            
        case ConstantLeanBodyMassActivity.type:
            self.setLeanBodyMass(viewController, assessmentEvent: assessmentEvent)
            break
            
        case ConstantBodyMassIndexActivity.type:
            self.setBodyMassIndex(viewController, assessmentEvent: assessmentEvent)
            break
            
        default:
            break
        }
    }
    
    static func readHKSample(_ sampleType:HKSampleType , completion: ((HKSample?, Error?) -> Void)!) {
        let store = HealthKitManager.getHealthKitStore()
        let sortDescriptor = NSSortDescriptor(key:HKSampleSortIdentifierStartDate, ascending: false)
        let limit = 1
        let sampleQuery = HKSampleQuery(sampleType: sampleType, predicate: nil, limit: limit, sortDescriptors: [sortDescriptor]) {
            (sampleQuery, results, error ) -> Void in
            if let failureDescription = error?.localizedDescription { assertionFailure(failureDescription) }
            let mostRecentSample = results!.first
            if completion != nil {
                completion(mostRecentSample,nil)
            }
        }
        store!.execute(sampleQuery)
    }
}
