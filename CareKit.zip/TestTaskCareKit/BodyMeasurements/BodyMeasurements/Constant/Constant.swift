//
//  Constant.swift
//  BodyMeasurements
//
//  Created by Ritesh  on 05/07/17.
//  Copyright © 2017 Ritesh. All rights reserved.
//

import Foundation
import UIKit

//MARK: - Activity constants
struct ConstantBodyMassActivity {
    static let id = "Body Mass"
    static let title = "Weight"
    static let text = "Get Weight from Health app"
    static let type = "Body Mass"
    static let color =  UIColor.init(red: 0.3, green: 0.2, blue: 0.9, alpha: 0.4)
}
struct ConstantHeightActivity {
    static let id = "Height"
    static let title = "Height"
    static let text = "Get Height from Health app"
    static let type = "Height"
    static let color =  UIColor.init(red: 0.3, green: 0.2, blue: 0.9, alpha: 0.4)
}
struct ConstantBodyFatActivity {
    static let id = "Body Fat"
    static let title = "Body Fat"
    static let text = "Get Body Fat from Health app"
    static let type = "Body Fat"
    static let color =  UIColor.init(red: 0.3, green: 0.2, blue: 0.9, alpha: 0.4)
}
struct ConstantLeanBodyMassActivity {
    static let id = "Lean Body Mass"
    static let title = "Lean Body Mass"
    static let text = "Get Lean Body Mass from Health app"
    static let type = "Lean Body Mass"
    static let color =  UIColor.init(red: 0.3, green: 0.2, blue: 0.9, alpha: 0.4)
}
struct ConstantBodyMassIndexActivity {
    static let id = "Body Mass Index"
    static let title = "Body Mass Index"
    static let text = "Get Lean Body Mass from Health app"
    static let type = "Body Mass Index"
    static let color =  UIColor.init(red: 0.3, green: 0.2, blue: 0.9, alpha: 0.4)
}

//MARK: - Alert constants
struct ConstantAlert {
    static let healthSettingMessage = "Please allow health kit to access this data."
}
