//
//  MessageAlert.swift
//  BodyMeasurements
//
//  Created by Ritesh  on 05/07/17.
//  Copyright © 2017 Ritesh. All rights reserved.
//

import UIKit

class MessageAlert: NSObject {
    
    static func displayAlert(alertTitle: String?, alertMessage: String?) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate

        let alertController = UIAlertController(title: alertTitle, message: alertMessage, preferredStyle: UIAlertControllerStyle.alert)
        let settingAction = UIAlertAction(title: "Settings", style: UIAlertActionStyle.default) { (action) in
            if #available(iOS 10.0, *) {
                UIApplication.shared.open(URL(string: "App-Prefs:root=Privacy&path=HEALTH")!)
            }
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.destructive, handler: nil)
        alertController.addAction(cancelAction)
        alertController.addAction(settingAction)
        appDelegate.window?.rootViewController?.present(alertController, animated: true, completion: nil)
    }
}
