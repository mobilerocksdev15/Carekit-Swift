//
//  DashboardViewController.swift
//  BodyMeasurements
//
//  Created by Ritesh  on 05/07/17.
//  Copyright © 2017 Ritesh. All rights reserved.
//

import UIKit
import CareKit

class DashboardViewController: UIViewController {
    
    
    //MARK: - View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    //MARK: - Actions
    @IBAction func showHealthKitData(_ sender: Any) {
        // Track Health Data
        HealthKitManager.authorizeHealthKit(completion: { (success, error) in
            assert(success, (error?.localizedDescription)!)
            DispatchQueue.main.async {
                let symptomTracker = CareKitManager.getSymptomTrackerController()
                symptomTracker.delegate = self
                symptomTracker.glyphTintColor = UIColor.init(red: 0.5, green: 0.2, blue: 0.9, alpha: 0.4)
                self.navigationController?.pushViewController(symptomTracker, animated: true)
            }
        })
    }
}

extension DashboardViewController: OCKSymptomTrackerViewControllerDelegate {
    
    func symptomTrackerViewController(_ viewController: OCKSymptomTrackerViewController, didSelectRowWithAssessmentEvent assessmentEvent: OCKCarePlanEvent) {
        HealthKitDataProvider.readHealthKitData(type: String(describing: assessmentEvent.activity.userInfo!["Type"]!), viewController, assessmentEvent: assessmentEvent)
    }
}
