//
//  HealthKitManager.swift
//  BodyMeasurements
//
//  Created by Ritesh  on 05/07/17.
//  Copyright © 2017 Ritesh. All rights reserved.
//

import UIKit
import HealthKit

class HealthKitManager: NSObject {
    
    static private var healthKitStore:HKHealthStore?
    
    //MARK: - HealthkitStore Creation
    static func getHealthKitStore() -> HKHealthStore?  {
        guard let store = healthKitStore else {
            healthKitStore = HKHealthStore()
            return healthKitStore
        }
        return store
    }
    
    //MARK: - Healthkit authorization
    static func authorizeHealthKit(completion: ((_ success:Bool, _ error:Error?) -> Void)!) {
        let store = self.getHealthKitStore()
        let typesSet : Set<HKSampleType> = [HKQuantityType.quantityType(forIdentifier: HKQuantityTypeIdentifier.bodyFatPercentage)! , HKQuantityType.quantityType(forIdentifier: HKQuantityTypeIdentifier.bodyMassIndex)!, HKQuantityType.quantityType(forIdentifier: HKQuantityTypeIdentifier.leanBodyMass)!, HKQuantityType.quantityType(forIdentifier: HKQuantityTypeIdentifier.height)!, HKQuantityType.quantityType(forIdentifier: HKQuantityTypeIdentifier.bodyMass)!]
        store?.requestAuthorization(toShare: typesSet, read: typesSet, completion: completion)
    }
    
}
